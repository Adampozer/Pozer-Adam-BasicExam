var elem = document.querySelector('.container')

document.createElement(elem);


for (var i = 0; i < array.length; i++) {
    elem = document.body.appendChild(array[i].picture);

}


keres() {


    var mezo = document.querySelector('#kereses').value
    for (var i = 0; i < array.length; i++) {
        if (mezo = array[i].name){

        }


    }
    document.querySelector('#outwrite').innerHTML=(`${array[i].name}` `${array[i].bio}`);
}